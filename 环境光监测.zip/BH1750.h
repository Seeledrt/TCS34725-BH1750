#ifndef _BH1750_H
#define _BH1750_H
#include "public.h"
#include "oled.h"
u8 readbit();
u8 readbyte();
void sendbit(u8);
void sendbyte(u8);
void ack(u8);
void start();
void end();
u8 Recvack();
void initbh1750();
void singlewrite(u8);
u16 doubleREAD();
#endif