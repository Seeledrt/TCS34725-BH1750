#ifndef _TCS34725_H
#define _TCS34725_H
#include "public.h"
void start_tcs();
void stop_tcs();
void tcs_write_byte(u8);
u8 tcs_read_byte();
void tcs_init();
void tcs_write_cmd(u8,u8);
u16 tcs_read_word(u8,u8);
void tcs_ack(u8);
u8 tcs_reack();
#endif 