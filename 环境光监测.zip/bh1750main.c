#include "BH1750.h"
#include "smg.h"
#include "lcd1602.h"
#include "TCS34725.h"
extern void lcd1602_write_cmd(u8 cmd);
extern void lcd1602_write_data(u8 dat);
void main()
{
    u8 RL = 0X16;
    u8 RH = 0X17;
    u8 GL = 0X18;
    u8 GH = 0X19;
    u8 BL = 0X1A;
    u8 BH = 0X1B;
    u8 i2 = 0;
    u8 show[8];
    u8 show1[21];
    char s[6];
    float ii1;
    u8 *str = s;
    int ii = 0;
    u16 i = 100, j = 110;
    u16 dataall = 0X0000;
    u16 RDATA = 0X0000;
    u16 GDATA = 0X0000;
    u16 BDATA = 0X0000;
    VCC = 1;
    GND = 0;
    ADDR = 0;
    s[5] = '\0';
    while (1)
    {

        initbh1750();
        singlewrite(0x20);
        // delay_ms(200);
        dataall = doubleREAD();
        ii1 = (dataall * 0.8333);
        ii = ((int)(ii1));
        show1[0] = ii / 10000;
        *str = 0x30 + show1[0]; //万
        show1[1] = ii % 10000 / 1000;
        *(str + 1) = 0x30 + show1[1]; //千
        show1[2] = ii % 10000 % 1000 / 100;
        *(str + 2) = 0x30 + show1[2];            //百
        show1[3] = ii % 10000 % 1000 % 100 / 10; //十
        *(str + 3) = 0x30 + show1[3];
        show1[4] = (ii % 10000 % 1000 % 100 % 10); //个
        *(str + 4) = 0x30 + show1[4];
        tcs_init();
        RDATA = (int)tcs_read_word(RL, RH);
        GDATA = tcs_read_word(GL, GH);
        BDATA = tcs_read_word(BL, BH);
        show1[5] = RDATA / 10000;
        *(str + 5) = 'R';
        //*(str+6) = 0x30 + show1[5];
        // show1[6]=RDATA%10000/1000;//未完成
        // *(str+7)=0X30+show1[6];
        lcd1602_init();
        for (i2; i2 < 8; i2++)
        {
            if (i2 < 5)
                show[i2] = gsmg_code[show1[i2]];
            else
                show[i2] = 0x00;
        }
        lcd1602_show_string(0, 0, str);
        while (i)
        {
            for (j = 110; j > 0; j--)
            {
            }
            i--;
            smg_display(show, 1);
        }
        i2 = 0;
        i = 100;
    }
}
