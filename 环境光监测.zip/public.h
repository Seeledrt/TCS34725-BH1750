#ifndef _public_H
#define _public_H

#include "reg52.h"
typedef unsigned int u16;	
typedef unsigned char u8;
sbit VCC = P1^2;
sbit GND = P1^3;
sbit SCL = P1^4;
sbit SDA = P1^5;
sbit ADDR = P1^6;
void delay_us(u16 ten_us);
void delay_ms(u16 ms);
#endif