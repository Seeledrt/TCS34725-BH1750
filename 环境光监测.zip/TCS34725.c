#include "TCS34725.h"
 u8 TCS_ADDRESS = 0X29;
void start_tcs() // tcs初始化信号
{
    SCL = 1;
    SDA = 1;
    delay_us(3);
    SCL = 1;
    SDA = 0;
}

void stop_tcs() // tcs停止信号
{
    SCL = 1;
    SDA = 0;
    delay_us(3);
    SDA = 1;
}
void tcs_write_byte(u8 i)
{
    u8 ii = 0;
    u8 dat_check = 0x80;
    start_tcs();
    SCL = 0; //拉低时钟线准备写入数据
    for (ii; ii < 8; ii++)
    {
        if (i & 0x80 == 0x80)
        {
            SDA = 1;
            delay_us(1);
            SCL = 1;
            delay_us(2);
            SCL = 0;
        }
        else
        {
            SDA = 0;
            delay_us(1);
            SCL = 1;
            delay_us(2);
            SCL = 0;
        }
        i <<= 1;
    }
    tcs_reack(); //每次写入一个字节就要接受一次应答信号
    stop_tcs();
}
u8 tcs_read_byte(u8 i)
{
    u8 ii = 0;
    u8 dat_recive = 0x00;
    start_tcs();
    tcs_write_byte((TCS_ADDRESS <<= 1) | 0x00);
    tcs_write_byte(i);                          //选择读取数据的位置（三种颜色的六个字节等）
    tcs_write_byte((TCS_ADDRESS <<= 1) | 0x01); //
    for (ii = 0; ii < 8; ii++)                  // 8位计数器
    {
        dat_recive <<= 1;  //循环8次，每次接收一个位，8次之后完成一个字节数据的接收
        SCL = 1;           //拉高时钟线
        delay_us(1);       //延时//读取SDA引脚的电平，如果是高电平，就是传输“1” //电平传输的是“0”
        dat_recive |= SDA; //读数据
        SCL = 0;           //拉低时钟线
        delay_us(1);       //延时
    }
    tcs_ack(0);
    stop_tcs();
    return dat_recive;
}
void tcs_write_cmd(u8 i, u8 dat) //写入需要写入的控制寄存器和相应的控制数据
{
    start_tcs();
    tcs_write_byte((TCS_ADDRESS <<= 1) | 0x00);
    delay_us(10);
    tcs_write_byte(i);
    delay_us(5);
    tcs_write_byte(dat);
    stop_tcs();
}
void tcs_init() // tcs初始化
{
    tcs_write_cmd(0x00, 0X07);
    tcs_write_cmd(0X01, 0XFF);
    tcs_write_cmd(0X03, 0XFF);
    tcs_write_cmd(0X0C, 0X00);
    tcs_write_cmd(0X0D, 0X02);
    tcs_write_cmd(0X0F, 0X01);
    tcs_write_byte(TCS_ADDRESS);
    tcs_write_byte(0X60);
}

u16 tcs_read_word(u8 L, u8 H) //读取一个字数据 先低位后高位
{
    u16 dataall = 0x00;
    u8 dat1, dat2;
    dat1 = tcs_read_byte(L);
    dat2 = tcs_read_byte(H);
    dataall = dataall | dat1;
    dataall <<= 8;
    dataall = dataall + dat2;
    return dataall;
}
void tcs_ack(u8 i)
{
    SDA = i;     //写应答信号
    SCL = 1;     //拉高时钟线
    delay_us(1); //延时
    SCL = 0;     //拉低时钟线
    delay_us(1); //延时
}
u8 tcs_reack()
{
    u8 mcy;
    SCL = 1;     //拉高时钟线
    delay_us(1); //延时
    mcy = SDA;
    SCL = 0;     //拉低时钟线
    delay_us(1); //延时
    return mcy;
}
